/*
 * (c) copyright 1986, Delft University of Technology
 * Delft, The Netherlands
 *

 * This software remains the property of the Delft University of Tech.
 * The software is a part of the Delft Ada Subset Compiler
 *
 * Permission to use, sell, duplicate or disclose the software
 * must be obtained, in writing, from the Delft University of Tech.
 *
 * For further information contact
 *	Jan van Katwijk
 *	Department of Mathemetics and Informatics
 *	Delft University of Technology
 *	julianalaan 132 Delft The Netherlands.
 *
 */

#include "../h/unix.h"
#include <stdio.h>

#ifdef VAX
int yyline;
#endif VAX

yyerror(s)
register char *s;
{
	fprintf (stderr, s);
	_cleanup ();
	return 1;
}
