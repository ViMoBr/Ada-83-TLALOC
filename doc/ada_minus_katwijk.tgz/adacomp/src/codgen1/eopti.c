eopti()
{
  error("unknown option");
}
